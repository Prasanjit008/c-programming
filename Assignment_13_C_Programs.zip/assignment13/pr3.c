/* Assignment 13 - Program 3
   Dynamically allocate an integer array and search for an element. */
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int n, key, found = 0;
    int *arr;

    printf("Enter the size of the array: ");
    if (scanf("%d", &n) != 1 || n <= 0)
    {
        printf("Invalid array size.\n");
        return 1;
    }

    arr = (int *)malloc(n * sizeof(int));
    if (arr == NULL)
    {
        printf("Memory allocation failed!\n");
        return 1;
    }

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    printf("Enter the element to search: ");
    scanf("%d", &key);

    for (int i = 0; i < n; i++)
    {
        if (arr[i] == key)
        {
            found = 1;
            break;
        }
    }

    if (found == 1)
        printf("Element %d is present in the array.\n", key);
    else
        printf("Element %d is absent in the array.\n", key);

    free(arr);
    return 0;
}
