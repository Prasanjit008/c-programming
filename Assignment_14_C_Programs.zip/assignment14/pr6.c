/* PR6: Find the sum of five integers passed from the command line.
   Usage: ./pr6 2 3 5 7 11 */
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int i, sum = 0;

    if (argc != 6) {
        printf("Usage: %s <num1> <num2> <num3> <num4> <num5>\n", argv[0]);
        return 1;
    }

    for (i = 1; i <= 5; i++)
        sum += atoi(argv[i]);

    printf("Sum = %d\n", sum);
    return 0;
}
