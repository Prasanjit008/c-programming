/* PR3: Convert lowercase characters to uppercase and uppercase to lowercase.
   Usage: ./pr3 source.txt converted.txt */
#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
    FILE *source, *destination;
    int ch;

    if (argc != 3) {
        printf("Usage: %s <source-file> <destination-file>\n", argv[0]);
        return 1;
    }

    source = fopen(argv[1], "r");
    if (source == NULL) {
        printf("Unable to open source file.\n");
        return 1;
    }

    destination = fopen(argv[2], "w");
    if (destination == NULL) {
        printf("Unable to create destination file.\n");
        fclose(source);
        return 1;
    }

    while ((ch = fgetc(source)) != EOF) {
        if (islower((unsigned char)ch))
            ch = toupper((unsigned char)ch);
        else if (isupper((unsigned char)ch))
            ch = tolower((unsigned char)ch);
        fputc(ch, destination);
    }

    fclose(source);
    fclose(destination);
    printf("Case conversion completed.\n");
    return 0;
}
