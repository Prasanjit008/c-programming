ASSIGNMENT 14 - C PROGRAMS

Files:
pr1.c - Count characters, words, blank spaces and tabs in a text file.
pr2.c - Copy the contents of one file to another (command-line filenames).
pr3.c - Convert lowercase to uppercase and uppercase to lowercase in a file.
pr4.c - Display the contents of a file using a command-line filename.
pr5.c - Copy the contents of one file into another file.
pr6.c - Find the sum of five integers passed through command-line arguments.
pr7.c - Display a full name passed through command-line arguments.

Compile each program on Linux:
cc pr1.c -o pr1
cc pr2.c -o pr2
...and similarly for the others.

Examples:
./pr1 input.txt
./pr2 source.txt destination.txt
./pr3 source.txt converted.txt
./pr4 input.txt
./pr5 source.txt destination.txt
./pr6 2 3 5 7 11
./pr7 Prasanjit Singh

Note: PR2 and PR5 are both included because the uploaded assignment lists them as separate questions, although their basic file-copy operation is similar.
