/* PR1: Count characters, words, blank spaces and tabs in a text file.
   Usage: ./pr1 input.txt */
#include <stdio.h>
#include <ctype.h>

int main(int argc, char *argv[])
{
    FILE *fp;
    int ch, inWord = 0;
    long characters = 0, words = 0, spaces = 0, tabs = 0;

    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    fp = fopen(argv[1], "r");
    if (fp == NULL) {
        printf("Unable to open file.\n");
        return 1;
    }

    while ((ch = fgetc(fp)) != EOF) {
        characters++;
        if (ch == ' ') spaces++;
        if (ch == '\t') tabs++;

        if (isspace((unsigned char)ch)) {
            inWord = 0;
        } else if (!inWord) {
            words++;
            inWord = 1;
        }
    }

    fclose(fp);
    printf("Characters: %ld\nWords: %ld\nBlank spaces: %ld\nTabs: %ld\n",
           characters, words, spaces, tabs);
    return 0;
}
