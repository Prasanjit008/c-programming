/* PR2: Copy the contents of one file to another using command-line arguments.
   Usage: ./pr2 source.txt destination.txt */
#include <stdio.h>

int main(int argc, char *argv[])
{
    FILE *source, *destination;
    int ch;

    if (argc != 3) {
        printf("Usage: %s <source-file> <destination-file>\n", argv[0]);
        return 1;
    }

    source = fopen(argv[1], "rb");
    if (source == NULL) {
        printf("Unable to open source file.\n");
        return 1;
    }

    destination = fopen(argv[2], "wb");
    if (destination == NULL) {
        printf("Unable to create destination file.\n");
        fclose(source);
        return 1;
    }

    while ((ch = fgetc(source)) != EOF)
        fputc(ch, destination);

    fclose(source);
    fclose(destination);
    printf("File copied successfully.\n");
    return 0;
}
