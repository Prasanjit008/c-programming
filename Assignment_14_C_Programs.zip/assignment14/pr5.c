/* PR5: Copy the contents of one file into another file.
   Usage: ./pr5 source.txt destination.txt */
#include <stdio.h>

int main(int argc, char *argv[])
{
    FILE *source, *destination;
    int ch;

    if (argc != 3) {
        printf("Usage: %s <source-file> <destination-file>\n", argv[0]);
        return 1;
    }

    source = fopen(argv[1], "r");
    if (source == NULL) {
        printf("Unable to open source file.\n");
        return 1;
    }

    destination = fopen(argv[2], "w");
    if (destination == NULL) {
        printf("Unable to open destination file.\n");
        fclose(source);
        return 1;
    }

    while ((ch = fgetc(source)) != EOF)
        fputc(ch, destination);

    fclose(source);
    fclose(destination);
    printf("File copied successfully.\n");
    return 0;
}
